<h1> Doormat </h1>
<p> A simple bot to send welcome and leave msgs ti your server! </p>

## Setup
+ Make sure to edit `config.js` to the correct values!
+ Run `npm i` and then `node index.js` and you should be good to go!

## Extra
+ A video explaining the usage of the bot can be found **[Here]()**
+ A webserver is added if ya wanna host on repl.it :D
