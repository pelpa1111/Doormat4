exports.Token = `ODg0ODMyNjEwNjc5OTM5MDcy.YTeOlQ.yR2nMdiQ5Ehifj3opTO6BOrRkd4`; //Bot Token
exports.WelChan = `885535872852824084`; //Channel ID where welcome msgs should go
exports.LeaveChan = `866160123600437301`; //Channel ID where leave msgs should go
exports.WelMsg = `<user> Welcome to the blackkcorbit server`; //Msg sent for the user joining.. use the "[user]" tag to mention the user \\ blackkcorbit "[user] joined the server!"
exports.WelImg =`https://png.pngtree.com/thumb_back/fh260/background/20200714/pngtree-modern-double-color-futuristic-neon-background-image_351866.jpg`; //Welcome Image Background Link \\ Default - A nice pic taken from reddit   
exports.LeaveImg = `https://png.pngtree.com/background/20210711/original/pngtree-dark-abstract-background-with-dark-overlap-layers-picture-image_1155641.jpg`; //Leave Image Bakcground Link \\ Default - A nice pic taken from reddit
exports.LeaveMsg = `<user> just died`; //Msg sent for the user leaving.. use the "[user]" tag to enter user's tag \\ Default - "[user] left the server :("